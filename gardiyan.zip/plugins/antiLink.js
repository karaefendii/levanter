
const { getAntiLink, bot, setAntiLink } = require('../lib/')

bot(
  {
    pattern: 'antilink ?(.*)',
    desc: 'Anti-link özelliğini aç/kapat',
    type: 'group',
    onlyGroup: true,
  },
  async (message, match) => {
    const antilink = await getAntiLink(message.jid, message.id)
    if (!match) {
      const durum = antilink.enabled ? 'aktif' : 'pasif'
      return await message.send(
        `_Antilink şu anda ${durum}_\n*Komut örnekleri:*\n- antilink aktif\n- antilink pasif\n- antilink kontrol`,
      )
    }

    if (match === 'aktif') {
      await setAntiLink(message.jid, true)
      return await message.send('*Antilink özelliği aktifleştirildi!*')
    }

    if (match === 'pasif') {
      await setAntiLink(message.jid, false)
      return await message.send('*Antilink özelliği pasifleştirildi!*')
    }

    if (antilink.enabled && match.includes('http')) {
      const adminlar = await message.groupAdmins(message.jid)
      const kimse = message.sender
      const linkMesaji = message.message

      if (!adminlar.includes(kimse)) {
        // Kullanıcıyı susturma
        await message.reply('*Link paylaşımı yasaktır! Mesajınız silindi.*')
        await message.delete(linkMesaji)

        // Sahibine bilgi verme
        const sahip = message.client.user.jid
        await message.client.sendMessage(
          sahip,
          `Grubunuzda bir link paylaşıldı:\nKim: @${kimse.split('@')[0]}\nMesaj: ${linkMesaji}\nOnay verin: *evet/hayır*`,
          { mentions: [kimse] },
        )
      }
    }
  },
)
