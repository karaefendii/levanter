
const { bot, isAdmin, setMute, getMute } = require('../lib')

bot(
  {
    pattern: 'sustur açık (\d+),(\d+)',
    desc: 'Antisel özelliğini açar (mesaj sayısı, süre).',
    type: 'group',
    onlyGroup: true,
  },
  async (message, match) => {
    const [mesajSayisi, dakika] = match.split(',').map((v) => parseInt(v))
    if (!mesajSayisi || !dakika) {
      return await message.send('*Lütfen geçerli bir mesaj sayısı ve süre belirtin. Örnek: sustur açık 5,10*')
    }

    await setMute(message.jid, { limit: mesajSayisi, duration: dakika })
    return await message.send(`*Antisel özelliği aktif!*
- Mesaj Limiti: ${mesajSayisi}
- Süre: ${dakika} dakika`)
  },
)

bot(
  {
    pattern: 'sustur kapat',
    desc: 'Antisel özelliğini kapatır.',
    type: 'group',
    onlyGroup: true,
  },
  async (message) => {
    await setMute(message.jid, null)
    return await message.send('*Antisel özelliği kapatıldı!*')
  },
)

// Logic to monitor messages and enforce Antisel rules
bot(
  {
    on: 'message',
    onlyGroup: true,
  },
  async (message) => {
    const muteSettings = await getMute(message.jid)
    if (!muteSettings) return

    const { limit, duration } = muteSettings
    const userMessages = await message.getUserMessages(message.sender, duration)

    if (userMessages.length >= limit) {
      // Sil mesajlar ve bilgi gönder
      await message.client.groupParticipantsUpdate(message.jid, [message.sender], 'remove')
      return await message.reply('*Bu Bölgede Benden İzin Almadan Kimse Kimseye Yükselemez!*')
    }
  },
)
